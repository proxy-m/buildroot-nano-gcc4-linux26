#if __POWERPC__
#include "MW_TclHeaderPPC"
#elif __CFM68K__
#include "MW_TclHeaderCFM68K"
#else
#include "MW_TclHeader68K"
#endif
