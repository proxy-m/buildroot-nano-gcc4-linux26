/* @(#)version.h	1.92 16/01/26 Copyright 2007-2016 J. Schilling */

/*
 * The version for cdrtools programs
 */
#define	VERSION	"3.02a06"
