/*--------------------------------*-C-*---------------------------------*
 * File:	init.c
 *----------------------------------------------------------------------*
 * $Id: init.c,v 1.44 2000/09/19 06:31:17 gcw Exp $
 *
 * All portions of code are copyright by their respective author/s.
 * Copyright (C) 1992      John Bovey, University of Kent at Canterbury <jdb@ukc.ac.uk>
 *				- original version
 * Copyright (C) 1994      Robert Nation <nation@rocket.sanders.lockheed.com>
 * 				- extensive modifications
 * Copyright (C) 1998,1999,2000 Geoff Wing <gcw@pobox.com>
 * 				- extensive modifications
 * Copyright (C) 1999      D J Hawkey Jr <hawkeyd@visi.com>
 *				- QNX support
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *---------------------------------------------------------------------*/
/*
 * Initialisation routines.
 */

#include "../config.h"		/* NECESSARY */
#include "rxvt.h"		/* NECESSARY */
#include "init.h"

#include <signal.h>

const char *const def_colorName[] = {
    COLOR_FOREGROUND,
    COLOR_BACKGROUND,
/* low-intensity colors */
    "Black",			/* 0: black             (#000000) */
#ifndef NO_BRIGHTCOLOR
    "Red3",			/* 1: red               (#CD0000) */
    "Green3",			/* 2: green             (#00CD00) */
    "Yellow3",			/* 3: yellow            (#CDCD00) */
    "Blue3",			/* 4: blue              (#0000CD) */
    "Magenta3",			/* 5: magenta           (#CD00CD) */
    "Cyan3",			/* 6: cyan              (#00CDCD) */
    "AntiqueWhite",		/* 7: white             (#FAEBD7) */
/* high-intensity colors */
    "Grey25",			/* 8: bright black      (#404040) */
#endif				/* NO_BRIGHTCOLOR */
    "Red",			/* 1/9: bright red      (#FF0000) */
    "Green",			/* 2/10: bright green   (#00FF00) */
    "Yellow",			/* 3/11: bright yellow  (#FFFF00) */
    "Blue",			/* 4/12: bright blue    (#0000FF) */
    "Magenta",			/* 5/13: bright magenta (#FF00FF) */
    "Cyan",			/* 6/14: bright cyan    (#00FFFF) */
    "White",			/* 7/15: bright white   (#FFFFFF) */
#ifndef NO_CURSORCOLOR
    COLOR_CURSOR_BACKGROUND,
    COLOR_CURSOR_FOREGROUND,
#endif				/* ! NO_CURSORCOLOR */
    NULL,			/* Color_pointer                  */
    NULL			/* Color_border                   */
#ifndef NO_BOLD_UNDERLINE_REVERSE
    ,
    NULL,			/* Color_BD                       */
    NULL,			/* Color_UL                       */
    NULL			/* Color_RV                       */
#endif				/* ! NO_BOLD_UNDERLINE_REVERSE */
#ifdef KEEP_SCROLLCOLOR
    ,
    COLOR_SCROLLBAR,
    COLOR_SCROLLTROUGH
#endif				/* KEEP_SCROLLCOLOR */
};

#ifdef MULTICHAR_SET
/* Multicharacter font names, roman fonts sized to match */
const char *const def_mfontName[] = {
    MFONT_LIST
};
#endif				/* MULTICHAR_SET */

const char *const def_fontName[] = {
    NFONT_LIST
};

/*----------------------------------------------------------------------*/
/* substitute system functions */
#if defined(__svr4__) && ! defined(_POSIX_VERSION)
/* INTPROTO */
int
rxvt_getdtablesize(void)
{
    struct rlimit   rlim;

    getrlimit(RLIMIT_NOFILE, &rlim);
    return rlim.rlim_cur;
}
#endif
/*----------------------------------------------------------------------*/
/* EXTPROTO */
int
rxvt_init_vars(rxvt_t *r)
{
#ifndef NULLS_ARE_NOT_ZEROS
    MEMSET(r, 0, sizeof(rxvt_t));
#endif
    r->h = (struct rxvt_hidden *)CALLOC(1, sizeof(struct rxvt_hidden));
    r->PixColors = (Pixel *)MALLOC(sizeof(Pixel) * TOTAL_COLORS);
    if (r->h == NULL || r->PixColors == NULL)
	return -1;
#ifdef NULLS_ARE_NOT_ZEROS
    r->Xdisplay = NULL;
    r->h->xa_compound_text = r->h->xa_multiple = r->h->xa_targets =
	r->h->xa_text = r->h->xa_timestamp = NULL;
    r->TermWin.fontset = NULL;
    r->h->ttydev = NULL;
# ifdef MENUBAR
    r->h->menubarGC = None;
    r->h->BuildMenu = NULL;	/* the menu currently being built */
#  if (MENUBAR_MAX > 1)
    r->h->CurrentBar = NULL;
#  endif			/* (MENUBAR_MAX > 1) */
# endif
# ifdef USE_XIM
    r->h->Input_Context = NULL;
# endif
    r->h->v_bufstr = NULL;
# ifdef RXVT_GRAPHICS
    r->h->gr_root = NULL;
    r->h->gr_last_id = None;
# endif
    r->h->buffer = NULL;
    r->h->compose.compose_ptr = NULL;
#endif				/* NULLS_ARE_NOT_ZEROS */

#if defined(XPM_BACKGROUND) || defined(TRANSPARENT)
    r->TermWin.pixmap = None;
#endif
#ifdef UTMP_SUPPORT
    r->h->next_utmp_action = SAVE;
#endif
#ifndef __CYGWIN32__
    r->h->next_tty_action = SAVE;
#endif
    r->h->MEvent.time = CurrentTime;
    r->h->MEvent.button = AnyButton;
    r->Options = DEFAULT_OPTIONS;
    r->h->want_refresh = 1;
    r->h->cmd_pid = -1;
    r->cmd_fd = r->tty_fd = r->Xfd = -1;
    r->h->changettyowner = 1;
    r->h->PrivateModes = r->h->SavedModes = PrivMode_Default;
    r->TermWin.ncol = 80;
    r->TermWin.nrow = 24;
    r->TermWin.int_bwidth = INTERNALBORDERWIDTH;
    r->TermWin.ext_bwidth = EXTERNALBORDERWIDTH;
    r->TermWin.saveLines = SAVELINES;
    r->numPixColors = TOTAL_COLORS;
#ifndef NO_NEW_SELECTION
    r->selection_style = NEW_SELECT;
#else
    r->selection_style = OLD_SELECT;
#endif
#ifndef NO_BRIGHTCOLOR
    r->h->colorfgbg = DEFAULT_RSTYLE;
#endif
#if defined (HOTKEY_CTRL) || defined (HOTKEY_META)
    r->h->ks_bigfont = XK_greater;
    r->ks_smallfont = XK_less;
#endif
    r->h->refresh_limit = 1;
    r->h->refresh_type = SLOW_REFRESH;
    r->h->prev_nrow = r->h->prev_ncol = -1;
#ifdef MULTICHAR_SET
    r->h->multichar_decode = rxvt_euc2jis;
#endif
    r->h->oldcursor.row = r->h->oldcursor.col = -1;
#ifdef XPM_BACKGROUND
/*  r->h->bgPixmap.w = r->h->bgPixmap.h = 0; */
    r->h->bgPixmap.x = r->h->bgPixmap.y = 50;
    r->h->bgPixmap.pixmap = None;
#endif
    r->h->last_bot = r->h->last_state = -1;
    r->h->old_height = -1;
#ifdef MENUBAR
    r->h->menu_readonly = 1;
# if !(MENUBAR_MAX > 1)
    r->h->CurrentBar = &(r->h->BarList);
# endif				/* (MENUBAR_MAX > 1) */
#endif
    return 0;
}

/* EXTPROTO */
void
rxvt_init_secondary(rxvt_t *r)
{
    r->h->ttygid = getgid();
    r->h->ttymode = S_IRUSR | S_IWUSR | S_IWGRP | S_IWOTH;
#ifdef TTY_GID_SUPPORT
    {
	struct group   *gr = getgrnam("tty");

	if (gr) {		/* change group ownership of tty to "tty" */
	    r->h->ttymode = S_IRUSR | S_IWUSR | S_IWGRP;
	    r->h->ttygid = gr->gr_gid;
	}
    }
#endif				/* TTY_GID_SUPPORT */
}

/*----------------------------------------------------------------------*/
/* EXTPROTO */
const char    **
rxvt_init_resources(rxvt_t *r, int argc, const char *const *argv)
{
    int             i, r_argc;
    char           *val;
    const char     *tmp;
    const char    **cmd_argv, **r_argv, **t2;

/*
 * Look for -exec option.  Find => split and make cmd_argv[] of command args
 */
    for (r_argc = 0; r_argc < argc; r_argc++)
	if (!STRCMP(argv[r_argc], "-e") || !STRCMP(argv[r_argc], "-exec"))
	    break;
    r_argv = (const char **)MALLOC(sizeof(char *) * (r_argc + 1));

    for (i = 0; i < r_argc; i++)
	r_argv[i] = (const char *)argv[i];
    r_argv[i] = NULL;
    if (r_argc == argc)
	cmd_argv = NULL;
    else {
	cmd_argv = (const char **)MALLOC(sizeof(char *) * (argc - r_argc));

	for (i = 0; i < argc - r_argc - 1; i++)
	    cmd_argv[i] = (const char *)argv[i + r_argc + 1];
	cmd_argv[i] = NULL;
    }

/* clear all resources */
    for (i = 0, t2 = (const char **)&(r->h->rs);
	 i < sizeof(r->h->rs) / sizeof(char *); i++)
	t2[i] = NULL;

    r->h->rs[Rs_name] = rxvt_r_basename(argv[0]);
    if (cmd_argv != NULL && cmd_argv[0] != NULL)
	r->h->rs[Rs_iconName] = r->h->rs[Rs_title] = rxvt_r_basename(cmd_argv[0]);
/*
 * Open display, get options/resources and create the window
 */
    if ((r->h->rs[Rs_display_name] = getenv("DISPLAY")) == NULL)
	r->h->rs[Rs_display_name] = ":0";

    rxvt_get_options(r, r_argc, r_argv);
    FREE(r_argv);

#ifdef LOCAL_X_IS_UNIX
    if (r->h->rs[Rs_display_name][0] == ':') {
	val = MALLOC(5 + STRLEN(r->h->rs[Rs_display_name]));
	STRCPY(val, "unix");
	STRCAT(val, r->h->rs[Rs_display_name]);
	r->Xdisplay = XOpenDisplay(val);
	FREE(val);
    }
#endif

    if (r->Xdisplay == NULL
	&& (r->Xdisplay = XOpenDisplay(r->h->rs[Rs_display_name])) == NULL) {
	rxvt_print_error("can't open display %s", r->h->rs[Rs_display_name]);
	exit(EXIT_FAILURE);
    }
#ifdef INEXPENSIVE_LOCAL_X_CALLS
    /* it's hard to determine further if we're on a local display or not */
    if (r->h->rs[Rs_display_name][0] == ':'
	|| STRNCMP(r->h->rs[Rs_display_name], "unix:", 5))
	r->h->display_is_local = 1;
    else
	r->h->display_is_local = 0;
#endif

    rxvt_extract_resources(r, r->Xdisplay, r->h->rs[Rs_name]);

/*
 * set any defaults not already set
 */
    if (!r->h->rs[Rs_title])
	r->h->rs[Rs_title] = r->h->rs[Rs_name];
    if (!r->h->rs[Rs_iconName])
	r->h->rs[Rs_iconName] = r->h->rs[Rs_title];
    if (r->h->rs[Rs_saveLines] && (i = atoi(r->h->rs[Rs_saveLines])) >= 0)
	r->TermWin.saveLines = (int16_t) i;
#ifndef NO_FRILLS
    if (r->h->rs[Rs_int_bwidth] && (i = atoi(r->h->rs[Rs_int_bwidth])) >= 0)
	r->TermWin.int_bwidth = (int16_t) i;
    if (r->h->rs[Rs_ext_bwidth] && (i = atoi(r->h->rs[Rs_ext_bwidth])) >= 0)
	r->TermWin.ext_bwidth = (int16_t) i;
#endif

/* no point having a scrollbar without having any scrollback! */
    if (!r->TermWin.saveLines)
	r->Options &= ~Opt_scrollBar;

#ifdef PRINTPIPE
    if (!r->h->rs[Rs_print_pipe])
	r->h->rs[Rs_print_pipe] = PRINTPIPE;
#endif
    if (!r->h->rs[Rs_cutchars])
	r->h->rs[Rs_cutchars] = CUTCHARS;
#ifndef NO_BACKSPACE_KEY
    if (!r->h->rs[Rs_backspace_key])
# ifdef DEFAULT_BACKSPACE
	r->h->key_backspace = DEFAULT_BACKSPACE;
# else
	r->h->key_backspace = "DEC";	/* can toggle between \033 or \177 */
# endif
    else {
	val = strdup(r->h->rs[Rs_backspace_key]);
	rxvt_Str_trim(val);
	rxvt_Str_escaped(val);
	r->h->key_backspace = val;
    }
#endif
#ifndef NO_DELETE_KEY
    if (!r->h->rs[Rs_delete_key])
# ifdef DEFAULT_DELETE
	r->h->key_delete = DEFAULT_DELETE;
# else
	r->h->key_delete = "\033[3~";
# endif
    else {
	val = strdup(r->h->rs[Rs_delete_key]);
	rxvt_Str_trim(val);
	rxvt_Str_escaped(val);
	r->h->key_delete = val;
    }
#endif
    if (r->h->rs[Rs_answerbackstring]) {
	rxvt_Str_trim((char *)r->h->rs[Rs_answerbackstring]);
	rxvt_Str_escaped((char *)r->h->rs[Rs_answerbackstring]);
    }

    if (r->h->rs[Rs_selectstyle]) {
	if (STRNCASECMP(r->h->rs[Rs_selectstyle], "oldword", 7) == 0)
	    r->selection_style = OLD_WORD_SELECT;
#ifndef NO_OLD_SELECTION
	else if (STRNCASECMP(r->h->rs[Rs_selectstyle], "old", 3) == 0)
	    r->selection_style = OLD_SELECT;
#endif
    }

#if defined(RXVT_SCROLLBAR) || !(defined(NEXT_SCROLLBAR) || defined(XTERM_SCROLLBAR))
    r->scrollBar.style = R_SB_RXVT;
    r->scrollBar.width = SB_WIDTH_RXVT;
#else
# ifdef NEXT_SCROLLBAR
    r->scrollBar.style = R_SB_NEXT;
    r->scrollBar.width = SB_WIDTH_NEXT;
# elif defined(XTERM_SCROLLBAR)
    r->scrollBar.style = R_SB_XTERM;
    r->scrollBar.width = SB_WIDTH_XTERM;
# endif
#endif

    if (r->h->rs[Rs_scrollstyle]) {
#ifdef NEXT_SCROLLBAR
	if (STRNCASECMP(r->h->rs[Rs_scrollstyle], "next", 4) == 0) {
	    r->scrollBar.style = R_SB_NEXT;
	    r->scrollBar.width = SB_WIDTH_NEXT;
	}
#endif
#ifdef XTERM_SCROLLBAR
	if (STRNCASECMP(r->h->rs[Rs_scrollstyle], "xterm", 5) == 0) {
	    r->scrollBar.style = R_SB_XTERM;
	    r->scrollBar.width = SB_WIDTH_XTERM;
	}
#endif
    }
#if defined(RXVT_SCROLLBAR)
    if (!(r->Options & Opt_scrollBar_floating)
	&& r->scrollBar.style == R_SB_RXVT)
	r->sb_shadow = SHADOW;
#endif

#ifndef NO_BOLDFONT
    if (r->h->rs[Rs_font] == NULL && r->h->rs[Rs_boldFont] != NULL) {
	r->h->rs[Rs_font] = r->h->rs[Rs_boldFont];
	r->h->rs[Rs_boldFont] = NULL;
    }
#endif
    for (i = 0; i < NFONTS; i++) {
	if (!r->h->rs[Rs_font + i])
	    r->h->rs[Rs_font + i] = def_fontName[i];
#ifdef MULTICHAR_SET
	if (!r->h->rs[Rs_mfont + i])
	    r->h->rs[Rs_mfont + i] = def_mfontName[i];
#endif
    }

#ifdef XTERM_REVERSE_VIDEO
/* this is how xterm implements reverseVideo */
    if (r->Options & Opt_reverseVideo) {
	if (!r->h->rs[Rs_color + Color_fg])
	    r->h->rs[Rs_color + Color_fg] = def_colorName[Color_bg];
	if (!r->h->rs[Rs_color + Color_bg])
	    r->h->rs[Rs_color + Color_bg] = def_colorName[Color_fg];
    }
#endif

    for (i = 0; i < NRS_COLORS; i++)
	if (!r->h->rs[Rs_color + i])
	    r->h->rs[Rs_color + i] = def_colorName[i];

#ifndef XTERM_REVERSE_VIDEO
/* this is how we implement reverseVideo */
    if (r->Options & Opt_reverseVideo)
	SWAP_IT(r->h->rs[Rs_color + Color_fg], r->h->rs[Rs_color + Color_bg], tmp);
#endif

/* convenient aliases for setting fg/bg to colors */
    rxvt_color_aliases(r, Color_fg);
    rxvt_color_aliases(r, Color_bg);
#ifndef NO_CURSORCOLOR
    rxvt_color_aliases(r, Color_cursor);
    rxvt_color_aliases(r, Color_cursor2);
#endif				/* NO_CURSORCOLOR */
    rxvt_color_aliases(r, Color_pointer);
    rxvt_color_aliases(r, Color_border);
#ifndef NO_BOLD_UNDERLINE_REVERSE
    rxvt_color_aliases(r, Color_BD);
    rxvt_color_aliases(r, Color_UL);
    rxvt_color_aliases(r, Color_RV);
#endif				/* ! NO_BOLD_UNDERLINE_REVERSE */

    return cmd_argv;
}

/*----------------------------------------------------------------------*/
/* EXTPROTO */
void
rxvt_init_env(rxvt_t *r)
{
    int             i;
    unsigned int    u;
    char           *val;

#ifdef DISPLAY_IS_IP
/* Fixup display_name for export over pty to any interested terminal
 * clients via "ESC[7n" (e.g. shells).  Note we use the pure IP number
 * (for the first non-loopback interface) that we get from
 * rxvt_network_display().  This is more "name-resolution-portable", if you
 * will, and probably allows for faster x-client startup if your name
 * server is beyond a slow link or overloaded at client startup.  Of
 * course that only helps the shell's child processes, not us.
 *
 * Giving out the display_name also affords a potential security hole
 */
    val = rxvt_network_display(r->h->rs[Rs_display_name]);
    r->h->rs[Rs_display_name] = (const char *)val;
    if (val == NULL)
#endif				/* DISPLAY_IS_IP */
	val = XDisplayString(r->Xdisplay);
    if (r->h->rs[Rs_display_name] == NULL)
	r->h->rs[Rs_display_name] = val;	/* use broken `:0' value */

    i = STRLEN(val);
    r->h->env_display = MALLOC((i + 9) * sizeof(char));

    sprintf(r->h->env_display, "DISPLAY=%s", val);

    /* avoiding the math library:
     * i = (int)(ceil(log10((unsigned int)r->TermWin.parent[0]))) */
    for (i = 0, u = (unsigned int)r->TermWin.parent[0]; u; u /= 10, i++) ;
    MAX_IT(i, 1);
    r->h->env_windowid = MALLOC((i + 10) * sizeof(char));

    sprintf(r->h->env_windowid, "WINDOWID=%u",
	    (unsigned int)r->TermWin.parent[0]);

/* add entries to the environment:
 * @ DISPLAY:   in case we started with -display
 * @ WINDOWID:  X window id number of the window
 * @ COLORTERM: terminal sub-name and also indicates its color
 * @ TERM:      terminal name
 * @ TERMINFO:	path to terminfo directory
 */
    putenv(r->h->env_display);
    putenv(r->h->env_windowid);
#ifdef RXVT_TERMINFO
    putenv("TERMINFO=" RXVT_TERMINFO);
#endif
    if (r->Xdepth <= 2)
	putenv("COLORTERM=" COLORTERMENV "-mono");
    else
	putenv("COLORTERM=" COLORTERMENVFULL);
    if (r->h->rs[Rs_term_name] != NULL) {
	r->h->env_term = MALLOC((STRLEN(r->h->rs[Rs_term_name]) + 6) * sizeof(char));

	sprintf(r->h->env_term, "TERM=%s", r->h->rs[Rs_term_name]);
	putenv(r->h->env_term);
    } else
	putenv("TERM=" TERMENV);

#ifdef HAVE_UNSETENV
/* avoid passing old settings and confusing term size */
    unsetenv("LINES");
    unsetenv("COLUMNS");
    unsetenv("TERMCAP");	/* terminfo should be okay */
#endif				/* HAVE_UNSETENV */
}

/*----------------------------------------------------------------------*/
/*
 * This is more or less stolen straight from XFree86 xterm.
 * This should support all European type languages.
 */
/* EXTPROTO */
void
rxvt_init_xlocale(rxvt_t *r)
{
    char           *locale = NULL;

#if !defined(NO_XSETLOCALE) || !defined(NO_SETLOCALE)
    locale = setlocale(LC_CTYPE, "");
#endif
#ifdef USE_XIM
    if (locale == NULL)
	rxvt_print_error("Setting locale failed.");
    else {
	/* To avoid Segmentation Fault in C locale: Solaris only? */
	rxvt_setTermFontSet(r, 0);
	if (STRCMP(locale, "C"))
	    XRegisterIMInstantiateCallback(r->Xdisplay, NULL, NULL, NULL,
					   rxvt_IMInstantiateCallback, NULL);
	else			/* just blast our way through */
	    rxvt_IMInstantiateCallback(r->Xdisplay, NULL, locale);
    }
#endif
}

/*----------------------------------------------------------------------*/
/* EXTPROTO */
void
rxvt_init_command(rxvt_t *r, const char *const *argv)
{
/*
 * Initialize the command connection.
 * This should be called after the X server connection is established.
 */

    r->h->xa_compound_text = XInternAtom(r->Xdisplay, "COMPOUND_TEXT", False);
    r->h->xa_multiple = XInternAtom(r->Xdisplay, "MULTIPLE", False);
    r->h->xa_targets = XInternAtom(r->Xdisplay, "TARGETS", False);
    r->h->xa_text = XInternAtom(r->Xdisplay, "TEXT", False);
    r->h->xa_timestamp = XInternAtom(r->Xdisplay, "TIMESTAMP", False);
/* Enable delete window protocol */
    r->h->wmDeleteWindow = XInternAtom(r->Xdisplay, "WM_DELETE_WINDOW", False);
    XSetWMProtocols(r->Xdisplay, r->TermWin.parent[0], &r->h->wmDeleteWindow, 1);

#ifdef OFFIX_DND
/* Enable OffiX Dnd (drag 'n' drop) protocol */
    r->h->DndProtocol = XInternAtom(r->Xdisplay, "DndProtocol", False);
    r->DndSelection = XInternAtom(r->Xdisplay, "DndSelection", False);
#endif				/* OFFIX_DND */

/* get number of available file descriptors */
#if defined(_POSIX_VERSION) || ! defined(__svr4__)
    r->num_fds = (int)sysconf(_SC_OPEN_MAX);
#else
    r->num_fds = rxvt_getdtablesize();
#endif

#ifdef META8_OPTION
    r->h->meta_char = (r->Options & Opt_meta8 ? 0x80 : C0_ESC);
#endif
    rxvt_get_ourmods(r);
    if (!(r->Options & Opt_scrollTtyOutput))
	r->h->PrivateModes |= PrivMode_TtyOutputInh;
    if (r->Options & Opt_scrollTtyKeypress)
	r->h->PrivateModes |= PrivMode_Keypress;
#ifndef NO_BACKSPACE_KEY
    if (STRCMP(r->h->key_backspace, "DEC") == 0)
	r->h->PrivateModes |= PrivMode_HaveBackSpace;
#endif
/* add value for scrollBar */
    if (scrollbar_visible()) {
	r->h->PrivateModes |= PrivMode_scrollBar;
	r->h->SavedModes |= PrivMode_scrollBar;
    }
    if (menubar_visible()) {
	r->h->PrivateModes |= PrivMode_menuBar;
	r->h->SavedModes |= PrivMode_menuBar;
    }
    greek_init();

    r->Xfd = XConnectionNumber(r->Xdisplay);

    if ((r->cmd_fd = rxvt_run_command(r, argv)) < 0) {
	rxvt_print_error("aborting");
	exit(EXIT_FAILURE);
    }
}

/*----------------------------------------------------------------------*/
/* INTPROTO */
void
rxvt_Get_Colours(rxvt_t *r)
{
    int             i;

    for (i = 0; i < (r->Xdepth <= 2 ? 2 : NRS_COLORS); i++) {
	XColor          xcol;

	if (!r->h->rs[Rs_color + i])
	    continue;

	if (!rxvt_rXParseAllocColor(r, &xcol, r->h->rs[Rs_color + i])) {
#ifndef XTERM_REVERSE_VIDEO
	    if (i < 2 && (r->Options & Opt_reverseVideo)) {
		r->h->rs[Rs_color + i] = def_colorName[!i];
	    } else
#endif
		r->h->rs[Rs_color + i] = def_colorName[i];
	    if (!r->h->rs[Rs_color + i])
		continue;
	    if (!rxvt_rXParseAllocColor(r, &xcol, r->h->rs[Rs_color + i])) {
		switch (i) {
		case Color_fg:
		case Color_bg:
		    /* fatal: need bg/fg color */
		    rxvt_print_error("aborting");
		    exit(EXIT_FAILURE);
		/* NOTREACHED */
		    break;
#ifndef NO_CURSORCOLOR
		case Color_cursor2:
		    xcol.pixel = r->PixColors[Color_fg];
		    break;
#endif				/* ! NO_CURSORCOLOR */
		case Color_pointer:
		    xcol.pixel = r->PixColors[Color_fg];
		    break;
		default:
		    xcol.pixel = r->PixColors[Color_bg];	/* None */
		    break;
		}
	    }
	}
	r->PixColors[i] = xcol.pixel;
	r->h->pixcolor_set |= 1 << i;
    }

    if (r->Xdepth <= 2 || !r->h->rs[Rs_color + Color_pointer])
	r->PixColors[Color_pointer] = r->PixColors[Color_fg];
    if (r->Xdepth <= 2 || !r->h->rs[Rs_color + Color_border])
	r->PixColors[Color_border] = r->PixColors[Color_fg];

/*
 * get scrollBar/menuBar shadow colors
 *
 * The calculations of topShadow/bottomShadow values are adapted
 * from the fvwm window manager.
 */
#ifdef KEEP_SCROLLCOLOR
    if (r->Xdepth <= 2) {	/* Monochrome */
	r->PixColors[Color_scroll] = r->PixColors[Color_fg];
	r->PixColors[Color_topShadow] = r->PixColors[Color_bg];
	r->PixColors[Color_bottomShadow] = r->PixColors[Color_bg];
    } else {
	XColor          xcol, white;

	/* bottomShadowColor */
	xcol.pixel = r->PixColors[Color_scroll];
	XQueryColor(r->Xdisplay, r->Xcmap, &xcol);

	xcol.red /= 2;
	xcol.green /= 2;
	xcol.blue /= 2;

	if (!rxvt_rXAllocColor(r, &xcol, "Color_bottomShadow"))
	    xcol.pixel = r->PixColors[minCOLOR];
	r->PixColors[Color_bottomShadow] = xcol.pixel;

	/* topShadowColor */
# ifdef PREFER_24BIT
	white.red = white.green = white.blue = (unsigned short)~0;
	rxvt_rXAllocColor(r, &white, "White");
/*        XFreeColors(r->Xdisplay, r->Xcmap, &white.pixel, 1, ~0); */
# else
	white.pixel = WhitePixel(r->Xdisplay, Xscreen);
	XQueryColor(r->Xdisplay, r->Xcmap, &white);
# endif

	xcol.pixel = r->PixColors[Color_scroll];
	XQueryColor(r->Xdisplay, r->Xcmap, &xcol);

	xcol.red = max((white.red / 5), xcol.red);
	xcol.green = max((white.green / 5), xcol.green);
	xcol.blue = max((white.blue / 5), xcol.blue);

	xcol.red = min(white.red, (xcol.red * 7) / 5);
	xcol.green = min(white.green, (xcol.green * 7) / 5);
	xcol.blue = min(white.blue, (xcol.blue * 7) / 5);

	if (!rxvt_rXAllocColor(r, &xcol, "Color_topShadow"))
	    xcol.pixel = r->PixColors[Color_White];
	r->PixColors[Color_topShadow] = xcol.pixel;
    }
#endif				/* KEEP_SCROLLCOLOR */
}

/*----------------------------------------------------------------------*/
/* color aliases, fg/bg bright-bold */
/* INTPROTO */
void
rxvt_color_aliases(rxvt_t *r, int idx)
{
    if (r->h->rs[Rs_color + idx] && isdigit(*(r->h->rs[Rs_color + idx]))) {
	int             i = atoi(r->h->rs[Rs_color + idx]);

	if (i >= 8 && i <= 15) {	/* bright colors */
	    i -= 8;
#ifndef NO_BRIGHTCOLOR
	    r->h->rs[Rs_color + idx] = r->h->rs[Rs_color + minBrightCOLOR + i];
	    return;
#endif
	}
	if (i >= 0 && i <= 7)	/* normal colors */
	    r->h->rs[Rs_color + idx] = r->h->rs[Rs_color + minCOLOR + i];
    }
}

/*----------------------------------------------------------------------*/
/*
 * Probe the modifier keymap to get the Meta (Alt) and Num_Lock settings
 * Use resource ``modifier'' to override the modifier
 */
/* INTPROTO */
void
rxvt_get_ourmods(rxvt_t *r)
{
    int             i, j, k;
    int             got_meta, got_numlock;
    int             realmeta, realalt;
    XModifierKeymap *map;
    KeyCode        *kc;
    const char     *cm;
    unsigned int    modmasks[] =
	{ Mod1Mask, Mod2Mask, Mod3Mask, Mod4Mask, Mod5Mask };

    got_meta = got_numlock = realmeta = realalt = 0;
    if (r->h->rs[Rs_modifier]
	&& r->h->rs[Rs_modifier][0] == 'm'
	&& r->h->rs[Rs_modifier][1] == 'o'
	&& r->h->rs[Rs_modifier][2] == 'd'
	&& r->h->rs[Rs_modifier][3] >= '1' && r->h->rs[Rs_modifier][3] <= '5'
	&& !r->h->rs[Rs_modifier][4]) {
	r->h->ModMetaMask = modmasks[(r->h->rs[Rs_modifier][3] - '1')];
	got_meta = 1;
    }
    map = XGetModifierMapping(r->Xdisplay);
    kc = map->modifiermap;
    for (i = 3; i < 8; i++) {
	k = i * map->max_keypermod;
	for (j = 0; j < map->max_keypermod; j++, k++) {
	    if (kc[k] == 0)
		break;
	    cm = NULL;
	    switch (XKeycodeToKeysym(r->Xdisplay, kc[k], 0)) {
	    case XK_Num_Lock:
		if (!got_numlock) {
		    r->h->ModNumLockMask = modmasks[i - 3];
		    got_numlock = 1;
		}
		break;
	    case XK_Meta_L:
	    case XK_Meta_R:
		cm = "meta";
		realmeta = i;
		break;
	    case XK_Alt_L:
	    case XK_Alt_R:
		cm = "alt";
		realalt = i;
		break;
	    case XK_Super_L:
	    case XK_Super_R:
		cm = "super";
		break;
	    case XK_Hyper_L:
	    case XK_Hyper_R:
		cm = "hyper";
		/* FALLTHROUGH */
	    default:
		break;
	    }
	    if (cm && r->h->rs[Rs_modifier]
		&& !STRNCASECMP(r->h->rs[Rs_modifier], cm, STRLEN(cm))) {
		r->h->ModMetaMask = modmasks[i - 3];
		got_meta = 1;
	    }
	}
    }
    XFreeModifiermap(map);
    if (!got_meta) {
	if (realmeta)
	    r->h->ModMetaMask = modmasks[realmeta - 3];
	else if (realalt)
	    r->h->ModMetaMask = modmasks[realalt - 3];
    }
}

/*----------------------------------------------------------------------*/
/* rxvt_Create_Windows() - Open and map the window */
/* EXTPROTO */
void
rxvt_Create_Windows(rxvt_t *r, int argc, const char *const *argv)
{
    Cursor          cursor;
    XClassHint      classHint;
    XWMHints        wmHint;
    XGCValues       gcvalue;

#ifdef PREFER_24BIT
    XSetWindowAttributes attributes;
    XWindowAttributes gattr;

    r->Xcmap = DefaultColormap(r->Xdisplay, Xscreen);
    r->h->Xvisual = DefaultVisual(r->Xdisplay, Xscreen);

    if (r->Options & Opt_transparent) {
	XGetWindowAttributes(r->Xdisplay, RootWindow(r->Xdisplay, Xscreen),
			     &gattr);
	r->Xdepth = gattr.depth;
    } else {
	r->Xdepth = DefaultDepth(r->Xdisplay, Xscreen);
/*
 * If depth is not 24, look for a 24bit visual.
 */
	if (r->Xdepth != 24) {
	    XVisualInfo     vinfo;

	    if (XMatchVisualInfo(r->Xdisplay, Xscreen, 24, TrueColor, &vinfo)) {
		r->Xdepth = 24;
		r->h->Xvisual = vinfo.visual;
		r->Xcmap = XCreateColormap(r->Xdisplay,
					   RootWindow(r->Xdisplay, Xscreen),
					   r->h->Xvisual, AllocNone);
	    }
	}
    }
#endif

/* grab colors before netscape does */
    rxvt_Get_Colours(r);

    rxvt_change_font(r, 1, NULL);
    rxvt_szhints_set(r);

/* parent window - reverse video so we can see placement errors
 * sub-window placement & size in rxvt_resize_subwindows()
 */

#ifdef PREFER_24BIT
    attributes.background_pixel = r->PixColors[Color_fg];
    attributes.border_pixel = r->PixColors[Color_border];
    attributes.colormap = r->Xcmap;
    r->TermWin.parent[0] = XCreateWindow(r->Xdisplay, Xroot,
					 r->szHint.x, r->szHint.y,
					 r->szHint.width, r->szHint.height,
					 r->TermWin.ext_bwidth,
					 r->Xdepth, InputOutput,
					 r->h->Xvisual,
					 CWBackPixel | CWBorderPixel |
					 CWColormap, &attributes);
#else
    r->TermWin.parent[0] = XCreateSimpleWindow(r->Xdisplay, Xroot,
					       r->szHint.x, r->szHint.y,
					       r->szHint.width,
					       r->szHint.height,
					       r->TermWin.ext_bwidth,
					       r->PixColors[Color_border],
					       r->PixColors[Color_fg]);
#endif
    rxvt_xterm_seq(r, XTerm_title, r->h->rs[Rs_title], CHAR_ST);
    rxvt_xterm_seq(r, XTerm_iconName, r->h->rs[Rs_iconName], CHAR_ST);
/* ignore warning about discarded `const' */
    classHint.res_name = (char *)r->h->rs[Rs_name];
    classHint.res_class = (char *)APL_CLASS;
    wmHint.input = True;
    wmHint.initial_state = (r->Options & Opt_iconic ? IconicState
						    : NormalState);
    wmHint.window_group = r->TermWin.parent[0];
    wmHint.flags = (InputHint | StateHint | WindowGroupHint);

    XSetWMProperties(r->Xdisplay, r->TermWin.parent[0], NULL, NULL,
		     (char **)argv, argc, &r->szHint, &wmHint, &classHint);

    XSelectInput(r->Xdisplay, r->TermWin.parent[0],
		 (KeyPressMask | FocusChangeMask
		  | VisibilityChangeMask | StructureNotifyMask));

/* vt cursor: Black-on-White is standard, but this is more popular */
    r->TermWin_cursor = XCreateFontCursor(r->Xdisplay, XC_xterm);
    {
	XColor          fg, bg;

	fg.pixel = r->PixColors[Color_pointer];
	XQueryColor(r->Xdisplay, r->Xcmap, &fg);
	bg.pixel = r->PixColors[Color_bg];
	XQueryColor(r->Xdisplay, r->Xcmap, &bg);
	XRecolorCursor(r->Xdisplay, r->TermWin_cursor, &fg, &bg);
    }

/* cursor (menuBar/scrollBar): Black-on-White */
    cursor = XCreateFontCursor(r->Xdisplay, XC_left_ptr);

/* the vt window */
    r->TermWin.vt = XCreateSimpleWindow(r->Xdisplay, r->TermWin.parent[0],
					0, 0,
					r->szHint.width, r->szHint.height,
					0,
					r->PixColors[Color_fg],
					r->PixColors[Color_bg]);
#ifdef DEBUG_X
    XStoreName(r->Xdisplay, r->TermWin.vt, "vt window");
#endif

    XDefineCursor(r->Xdisplay, r->TermWin.vt, r->TermWin_cursor);
    XSelectInput(r->Xdisplay, r->TermWin.vt,
		 (ExposureMask | ButtonPressMask | ButtonReleaseMask |
		  Button1MotionMask | Button3MotionMask));

/* scrollBar: size doesn't matter */
    r->scrollBar.win = XCreateSimpleWindow(r->Xdisplay, r->TermWin.parent[0],
					   0, 0,
					   1, 1,
					   0,
					   r->PixColors[Color_fg],
					   r->PixColors[Color_bg]);
#ifdef DEBUG_X
    XStoreName(r->Xdisplay, r->scrollBar.win, "scrollbar");
#endif

    XDefineCursor(r->Xdisplay, r->scrollBar.win, cursor);
    XSelectInput(r->Xdisplay, r->scrollBar.win,
		 (ExposureMask | ButtonPressMask | ButtonReleaseMask |
		  Button1MotionMask | Button2MotionMask | Button3MotionMask));

    {				/* ONLYIF MENUBAR */
	rxvt_create_menuBar(r, cursor);
    }

#ifdef XPM_BACKGROUND
    if (r->h->rs[Rs_backgroundPixmap] != NULL && !(r->Options & Opt_transparent)) {
	const char     *p = r->h->rs[Rs_backgroundPixmap];

	if ((p = STRCHR(p, ';')) != NULL) {
	    p++;
	    rxvt_scale_pixmap(r, p);
	}
	rxvt_set_bgPixmap(r, r->h->rs[Rs_backgroundPixmap]);
	rxvt_scr_touch(r, True);
    }
#endif

/* graphics context for the vt window */
    gcvalue.font = r->TermWin.font->fid;
    gcvalue.foreground = r->PixColors[Color_fg];
    gcvalue.background = r->PixColors[Color_bg];
    gcvalue.graphics_exposures = 1;
    r->TermWin.gc = XCreateGC(r->Xdisplay, r->TermWin.vt,
			      GCForeground | GCBackground |
			      GCFont | GCGraphicsExposures, &gcvalue);

#if defined(MENUBAR) || defined(RXVT_SCROLLBAR)
    gcvalue.foreground = r->PixColors[Color_topShadow];
    r->h->topShadowGC = XCreateGC(r->Xdisplay, r->TermWin.vt,
				  GCForeground, &gcvalue);
    gcvalue.foreground = r->PixColors[Color_bottomShadow];
    r->h->botShadowGC = XCreateGC(r->Xdisplay, r->TermWin.vt,
				  GCForeground, &gcvalue);
    gcvalue.foreground = (r->Xdepth <= 2 ? r->PixColors[Color_fg]
					 : r->PixColors[Color_scroll]);
    r->h->scrollbarGC = XCreateGC(r->Xdisplay, r->TermWin.vt,
				  GCForeground, &gcvalue);
#endif
}

/*----------------------------------------------------------------------*/
/*
 * Run the command in a subprocess and return a file descriptor for the
 * master end of the pseudo-teletype pair with the command talking to
 * the slave.
 */
/* INTPROTO */
int
rxvt_run_command(rxvt_t *r, const char *const *argv)
{
    int             i, cfd;

    if ((cfd = rxvt_get_ptytty(r)) < 0)
	return -1;

/* install exit handler for cleanup */
#ifdef HAVE_ATEXIT
    atexit(rxvt_clean_exit);
#else
# if defined (__sun__)
    on_exit(rxvt_clean_exit, NULL);	/* non-ANSI exit handler */
# endif
#endif

/*
 * Close all unused file descriptors
 * We don't want them, we don't need them.
 */
    for (i = 0; i < r->num_fds; i++) {
	if (i == STDERR_FILENO || i == cfd || i == r->tty_fd || i == r->Xfd)
	    continue;
	close(i);
    }

    signal(SIGHUP, rxvt_Exit_signal);
#ifndef __svr4__
    signal(SIGINT, rxvt_Exit_signal);
#endif
    signal(SIGQUIT, rxvt_Exit_signal);
    signal(SIGTERM, rxvt_Exit_signal);
    signal(SIGCHLD, rxvt_Child_signal);

/* need to trap SIGURG for SVR4 (Unixware) rlogin */
/* signal (SIGURG, SIG_DFL); */

#ifndef __QNX__
/* spin off the command interpreter */
    switch (r->h->cmd_pid = fork()) {
    case -1:
	rxvt_print_error("can't fork");
	return -1;
    case 0:
	close(cfd);		/* only keep r->tty_fd open */
	close(r->Xfd);
#ifndef DEBUG_TTY
	close(STDERR_FILENO);
#endif
	rxvt_run_child(r, argv);
	exit(EXIT_FAILURE);
    /* NOTREACHED */
    default:
	close(r->tty_fd);	/* keep STDERR_FILENO, r->cmd_fd, r->Xfd open */
	break;
    }
#else				/* __QNX__ uses qnxspawn() */
    fchmod(r->tty_fd, 0622);
    fcntl(r->tty_fd, F_SETFD, FD_CLOEXEC);
    fcntl(r->cmd_fd, F_SETFD, FD_CLOEXEC);

    if (rxvt_run_child(r, argv) == -1)
	exit(EXIT_FAILURE);
#endif
/*
 * Reduce r->num_fds to what we use, so select() is more efficient
 */
    r->num_fds = max(STDERR_FILENO, cfd);
    MAX_IT(r->num_fds, r->Xfd);
    r->num_fds++;		/* counts from 0 */

    rxvt_privileged_utmp(r, SAVE);
    return cfd;
}

/* ------------------------------------------------------------------------- *
 *                          CHILD PROCESS OPERATIONS                         *
 * ------------------------------------------------------------------------- */
/*
 * The only open file descriptor is the slave tty - so no error messages.
 * returns are fatal
 */
/* INTPROTO */
int
rxvt_run_child(rxvt_t *r, const char *const *argv)
{
    int             fd;
    char           *login;

#ifndef __QNX__
/* ---------------------------------------- */
# ifdef HAVE_SETSID
    setsid();
# endif
# if defined(HAVE_SETPGID)
    setpgid(0, 0);
# elif defined(HAVE_SETPGRP)
    setpgrp(0, 0);
# endif
/* ---------------------------------------- */
# ifdef TIOCNOTTY
    fd = open("/dev/tty", O_RDWR | O_NOCTTY);
    D_TTY((stderr, "rxvt_run_child(): Voiding tty associations: previous=%s", fd < 0 ? "no" : "yes"));
    if (fd >= 0) {
	ioctl(fd, TIOCNOTTY, 0);	/* void tty associations */
	close(fd);
    }
# endif
/* ---------------------------------------- */
    fd = open("/dev/tty", O_RDWR | O_NOCTTY);
    D_TTY((stderr, "rxvt_run_child(): /dev/tty has controlling tty? %s", fd < 0 ? "no (good)" : "yes (bad)"));
    if (fd >= 0)
	close(fd);		/* ouch: still have controlling tty */
/* ---------------------------------------- */
# if defined(TIOCSCTTY)
    if (ioctl(r->tty_fd, TIOCSCTTY, 0) < 0 && errno != EINVAL)
# elif defined(TIOCSETCTTY)
    if (ioctl(r->tty_fd, TIOCSETCTTY, 0) < 0)
# endif
/* ---------------------------------------- */
/*
 * If we can't force the only open file descriptor to be the controlling
 * terminal, close it and open a new one: _some_ systems make it automatically
 * the controlling terminal
 */
    {
	close(r->tty_fd);
	r->tty_fd = open(r->h->ttydev, O_RDWR, 0);
	D_TTY((stderr, "rxvt_run_child(): couldn't set controlling terminal, trying again: %s", r->tty_fd < 0 ? "no (bad)" : "yes (good)"));
    }
/* ---------------------------------------- */
    fd = open("/dev/tty", O_WRONLY);
    D_TTY((stderr, "rxvt_run_child(): do we have controlling tty now: %s", fd < 0 ? "no (fatal)" : "yes (good)"));
    if (fd < 0)
	return -1;		/* fatal */
    close(fd);
/* ---------------------------------------- */
# if 0
    close(r->tty_fd);
    r->tty_fd = open(r->h->ttydev, O_RDWR, 0);
    D_TTY((stderr, "rxvt_run_child(): reopening tty: %s", r->tty_fd < 0 ? "no (fatal)" : "yes (good)"));
    if (r->tty_fd < 0)
	return -1;
# endif
    D_TTY((stderr, "rxvt_run_child(): tcgetpgrp(): %d  getpgrp(): %d\n", tcgetpgrp(r->tty_fd), getpgrp()));
/* ---------------------------------------- */
/* Reopen stdin, stdout and stderr over the tty file descriptor */
    dup2(r->tty_fd, STDIN_FILENO);
    dup2(r->tty_fd, STDOUT_FILENO);
    dup2(r->tty_fd, STDERR_FILENO);
    if (r->tty_fd > 2)
	close(r->tty_fd);
#endif				/* ! __QNX__ */

    SET_TTYMODE(STDIN_FILENO, &(r->h->tio));	/* init terminal attributes */

    if (r->Options & Opt_console) {	/* be virtual console, fail silently */
#ifdef TIOCCONS
	unsigned int    on = 1;

	ioctl(STDIN_FILENO, TIOCCONS, &on);
#elif defined (SRIOCSREDIR)
	fd = open(CONSOLE, O_WRONLY, 0);
	if (fd < 0 || ioctl(fd, SRIOCSREDIR, 0) < 0) {
	    if (fd >= 0)
		close(fd);
	}
#endif				/* SRIOCSREDIR */
    }

    rxvt_tt_winsize(r, STDIN_FILENO);	/* set window size */

/* reset signals and spin off the command interpreter */
    signal(SIGINT, SIG_DFL);
    signal(SIGQUIT, SIG_DFL);
    signal(SIGCHLD, SIG_DFL);
/*
 * mimick login's behavior by disabling the job control signals
 * a shell that wants them can turn them back on
 */
#ifdef SIGTSTP
    signal(SIGTSTP, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGTTOU, SIG_IGN);
#endif				/* SIGTSTP */

#ifndef __QNX__
/* command interpreter path */
    if (argv != NULL) {
# ifdef DEBUG_CMD
	int             i;

	for (i = 0; argv[i]; i++)
	    fprintf(stderr, "argv [%d] = \"%s\"\n", i, argv[i]);
# endif
	execvp(argv[0], (char *const *)argv);
	/* no error message: STDERR is closed! */
    } else {
	const char     *argv0, *shell;

	if ((shell = getenv("SHELL")) == NULL || *shell == '\0')
	    shell = "/bin/sh";

	argv0 = (const char *)rxvt_r_basename(shell);
	if (r->Options & Opt_loginShell) {
	    login = MALLOC((STRLEN(argv0) + 2) * sizeof(char));

	    login[0] = '-';
	    STRCPY(&login[1], argv0);
	    argv0 = login;
	}
	execlp(shell, argv0, NULL);
	/* no error message: STDERR is closed! */
    }
#else				/* __QNX__ uses qnxspawn() */
    {
	char            iov_a[10] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
	char           *command = NULL, fullcommand[_MAX_PATH];
	char          **arg_v, *arg_a[2] = { NULL, NULL };

	if (argv != NULL) {
	    if (access(argv[0], X_OK) == -1) {
		if (strchr(argv[0], '/') == NULL) {
		    searchenv(argv[0], "PATH", fullcommand);
		    if (fullcommand[0] != '\0')
			command = fullcommand;
		}
		if (access(command, X_OK) == -1)
		    return -1;
	    } else
		command = argv[0];
	    arg_v = argv;
	} else {
	    if ((command = getenv("SHELL")) == NULL || *command == '\0')
		command = "/bin/sh";

	    arg_a[0] = my_basename(command);
	    if (r->Options & Opt_loginShell) {
		login = MALLOC((STRLEN(arg_a[0]) + 2) * sizeof(char));

		login[0] = '-';
		STRCPY(&login[1], arg_a[0]);
		arg_a[0] = login;
	    }
	    arg_v = arg_a;
	}
	iov_a[0] = iov_a[1] = iov_a[2] = r->tty_fd;
	r->h->cmd_pid = qnx_spawn(0, 0, 0, -1, -1,
			       _SPAWN_SETSID | _SPAWN_TCSETPGRP,
			       command, arg_v, environ, iov_a, 0);
	if (login)
	    FREE(login);
	close(r->tty_fd);
	return r->h->cmd_pid;
    }
#endif
    return -1;
}

/* ------------------------------------------------------------------------- *
 *                  GET PSEUDO TELETYPE - MASTER AND SLAVE                   *
 * ------------------------------------------------------------------------- */
/*
 * On failure, returns -1.
 * If successful, file descriptors r->cmd_fd and r->tty_fd point to the master
 * and slave parts respectively; and r->h->ttydev is the name of the slave.
 */
/* INTPROTO */
int
rxvt_get_ptytty(rxvt_t *r)
{
    int             pfd;
    char           *ptydev;

#ifdef PTYS_ARE_OPENPTY
    char            tty_name[] = "/dev/pts/????";

    if (openpty(&pfd, &tty_fd, tty_name, NULL, NULL) != -1) {
	r->h->ttydev = strdup(tty_name);
	goto Found_pty;
    }
#endif
#ifdef PTYS_ARE__GETPTY
    ptydev = r->h->ttydev = _getpty(&pfd, O_RDWR | O_NDELAY | O_NOCTTY, 0622, 0);
    if (ptydev != NULL)
	goto Found_pty;
#endif
#ifdef PTYS_ARE_GETPTY
    while ((ptydev = getpty()) != NULL)
	if ((pfd = open(ptydev, O_RDWR | O_NOCTTY, 0)) >= 0) {
	    r->h->ttydev = ptydev;
	    goto Found_pty;
	}
#endif
#if defined(HAVE_GRANTPT) && defined(HAVE_UNLOCKPT)
# if defined(PTYS_ARE_GETPT) || defined(PTYS_ARE_PTMX)
    {
	extern char    *ptsname();

#  ifdef PTYS_ARE_GETPT
	if ((pfd = getpt()) >= 0) {
#  else
	if ((pfd = open("/dev/ptmx", O_RDWR | O_NOCTTY, 0)) >= 0) {
#  endif
	    if (grantpt(pfd) == 0	/* change slave permissions */
		&& unlockpt(pfd) == 0) {	/* slave now unlocked */
		ptydev = r->h->ttydev = ptsname(pfd);	/* get slave's name */
		r->h->changettyowner = 0;
		goto Found_pty;
	    }
	    close(pfd);
	}
    }
# endif
#endif
#ifdef PTYS_ARE_PTC
    if ((pfd = open("/dev/ptc", O_RDWR | O_NOCTTY, 0)) >= 0) {
	ptydev = r->h->ttydev = ttyname(pfd);
	goto Found_pty;
    }
#endif
#ifdef PTYS_ARE_CLONE
    if ((pfd = open("/dev/ptym/clone", O_RDWR | O_NOCTTY, 0)) >= 0) {
	ptydev = r->h->ttydev = ptsname(pfd);
	goto Found_pty;
    }
#endif
#ifdef PTYS_ARE_NUMERIC
    {
	int             idx;
	char           *c1, *c2;
	char            pty_name[] = "/dev/ptyp???";
	char            tty_name[] = "/dev/ttyp???";

	ptydev = pty_name;
	r->h->ttydev = tty_name;

	c1 = &(pty_name[sizeof(pty_name) - 4]);
	c2 = &(tty_name[sizeof(tty_name) - 4]);
	for (idx = 0; idx < 256; idx++) {
	    sprintf(c1, "%d", idx);
	    sprintf(c2, "%d", idx);
	    if (access(r->h->ttydev, F_OK) < 0) {
		idx = 256;
		break;
	    }
	    if ((pfd = open(ptydev, O_RDWR | O_NOCTTY, 0)) >= 0) {
		if (access(r->h->ttydev, R_OK | W_OK) == 0) {
		    r->h->ttydev = strdup(tty_name);
		    goto Found_pty;
		}
		close(pfd);
	    }
	}
    }
#endif
#ifdef PTYS_ARE_SEARCHED
    {
	int             len;
	const char     *c1, *c2;
	char            pty_name[] = "/dev/pty??";
	char            tty_name[] = "/dev/tty??";

	len = sizeof(pty_name) - 3;
	ptydev = pty_name;
	r->h->ttydev = tty_name;

# define PTYCHAR1	"pqrstuvwxyz"
# define PTYCHAR2	"0123456789abcdef"
	for (c1 = PTYCHAR1; *c1; c1++) {
	    ptydev[len] = r->h->ttydev[len] = *c1;
	    for (c2 = PTYCHAR2; *c2; c2++) {
		ptydev[len + 1] = r->h->ttydev[len + 1] = *c2;
		if ((pfd = open(ptydev, O_RDWR | O_NOCTTY, 0)) >= 0) {
		    if (access(r->h->ttydev, R_OK | W_OK) == 0) {
			r->h->ttydev = strdup(tty_name);
			goto Found_pty;
		    }
		    close(pfd);
		}
	    }
	}
    }
#endif

    rxvt_print_error("can't open pseudo-tty");
    return -1;

  Found_pty:
    r->cmd_fd = pfd;
    fcntl(r->cmd_fd, F_SETFL, O_NDELAY);
    rxvt_privileged_ttydev(r, SAVE);
    if (r->tty_fd == -1
	&& (r->tty_fd = open(r->h->ttydev, O_RDWR | O_NOCTTY, 0)) < 0) {
	rxvt_print_error("can't open slave tty %s", r->h->ttydev);
	close(pfd);
	return -1;
    }
#if defined(PTYS_ARE_PTMX) && defined(I_PUSH)
/*
 * Push STREAMS modules:
 *    ptem: pseudo-terminal hardware emulation module.
 *    ldterm: standard terminal line discipline.
 *    ttcompat: V7, 4BSD and XENIX STREAMS compatibility module.
 */
#ifdef HAVE_ISASTREAM
    if (isastream(r->tty_fd) == 1)
#endif
    if (!r->h->changettyowner) {
	D_TTY((stderr, "rxvt_get_ptytty(): STREAMS pushing"));
	ioctl(r->tty_fd, I_PUSH, "ptem");
	ioctl(r->tty_fd, I_PUSH, "ldterm");
	ioctl(r->tty_fd, I_PUSH, "ttcompat");
    }
#endif

    rxvt_get_ttymode(&(r->h->tio));

    return r->cmd_fd;
}

/* ------------------------------------------------------------------------- *
 *                            GET TTY CURRENT STATE                          *
 * ------------------------------------------------------------------------- */
/* rxvt_get_ttymode() */
/* INTPROTO */
void
rxvt_get_ttymode(ttymode_t *tio)
{
#ifdef HAVE_TERMIOS_H
/*
 * standard System V termios interface
 */
    if (GET_TERMIOS(STDIN_FILENO, tio) < 0) {
	/* return error - use system defaults */
	tio->c_cc[VINTR] = CINTR;
	tio->c_cc[VQUIT] = CQUIT;
	tio->c_cc[VERASE] = CERASE;
	tio->c_cc[VKILL] = CKILL;
	tio->c_cc[VSTART] = CSTART;
	tio->c_cc[VSTOP] = CSTOP;
	tio->c_cc[VSUSP] = CSUSP;
# ifdef VDSUSP
	tio->c_cc[VDSUSP] = CDSUSP;
# endif
# ifdef VREPRINT
	tio->c_cc[VREPRINT] = CRPRNT;
# endif
# ifdef VDISCRD
	tio->c_cc[VDISCRD] = CFLUSH;
# endif
# ifdef VWERSE
	tio->c_cc[VWERSE] = CWERASE;
# endif
# ifdef VLNEXT
	tio->c_cc[VLNEXT] = CLNEXT;
# endif
    }
    tio->c_cc[VEOF] = CEOF;
    tio->c_cc[VEOL] = VDISABLE;
# ifdef VEOL2
    tio->c_cc[VEOL2] = VDISABLE;
# endif
# ifdef VSWTC
    tio->c_cc[VSWTC] = VDISABLE;
# endif
# ifdef VSWTCH
    tio->c_cc[VSWTCH] = VDISABLE;
# endif
# if VMIN != VEOF
    tio->c_cc[VMIN] = 1;
# endif
# if VTIME != VEOL
    tio->c_cc[VTIME] = 0;
# endif

/* input modes */
    tio->c_iflag = (BRKINT | IGNPAR | ICRNL | IXON
# ifdef IMAXBEL
		    | IMAXBEL
# endif
	);

/* output modes */
    tio->c_oflag = (OPOST | ONLCR);

/* control modes */
    tio->c_cflag = (CS8 | CREAD);

/* line discipline modes */
    tio->c_lflag = (ISIG | ICANON | IEXTEN | ECHO | ECHOE | ECHOK
# if defined (ECHOCTL) && defined (ECHOKE)
		    | ECHOCTL | ECHOKE
# endif
	);
# else				/* HAVE_TERMIOS_H */

/*
 * sgtty interface
 */

/* get parameters -- gtty */
    if (ioctl(STDIN_FILENO, TIOCGETP, &(tio->sg)) < 0) {
	tio->sg.sg_erase = CERASE;	/* ^H */
	tio->sg.sg_kill = CKILL;	/* ^U */
    }
    tio->sg.sg_flags = (CRMOD | ECHO | EVENP | ODDP);

/* get special characters */
    if (ioctl(STDIN_FILENO, TIOCGETC, &(tio->tc)) < 0) {
	tio->tc.t_intrc = CINTR;	/* ^C */
	tio->tc.t_quitc = CQUIT;	/* ^\ */
	tio->tc.t_startc = CSTART;	/* ^Q */
	tio->tc.t_stopc = CSTOP;	/* ^S */
	tio->tc.t_eofc = CEOF;	/* ^D */
	tio->tc.t_brkc = -1;
    }
/* get local special chars */
    if (ioctl(STDIN_FILENO, TIOCGLTC, &(tio->lc)) < 0) {
	tio->lc.t_suspc = CSUSP;	/* ^Z */
	tio->lc.t_dsuspc = CDSUSP;	/* ^Y */
	tio->lc.t_rprntc = CRPRNT;	/* ^R */
	tio->lc.t_flushc = CFLUSH;	/* ^O */
	tio->lc.t_werasc = CWERASE;	/* ^W */
	tio->lc.t_lnextc = CLNEXT;	/* ^V */
    }
/* get line discipline */
    ioctl(STDIN_FILENO, TIOCGETD, &(tio->line));
# ifdef NTTYDISC
    tio->line = NTTYDISC;
# endif				/* NTTYDISC */
    tio->local = (LCRTBS | LCRTERA | LCTLECH | LPASS8 | LCRTKIL);
#endif				/* HAVE_TERMIOS_H */

/*
 * Debugging
 */
#ifdef DEBUG_TTYMODE
#ifdef HAVE_TERMIOS_H
/* c_iflag bits */
    fprintf(stderr, "Input flags\n");

/* cpp token stringize doesn't work on all machines <sigh> */
# define FOO(flag,name)			\
    if ((tio->c_iflag) & flag)		\
	fprintf (stderr, "%s ", name)

/* c_iflag bits */
    FOO(IGNBRK, "IGNBRK");
    FOO(BRKINT, "BRKINT");
    FOO(IGNPAR, "IGNPAR");
    FOO(PARMRK, "PARMRK");
    FOO(INPCK, "INPCK");
    FOO(ISTRIP, "ISTRIP");
    FOO(INLCR, "INLCR");
    FOO(IGNCR, "IGNCR");
    FOO(ICRNL, "ICRNL");
    FOO(IXON, "IXON");
    FOO(IXOFF, "IXOFF");
# ifdef IUCLC
    FOO(IUCLC, "IUCLC");
# endif
# ifdef IXANY
    FOO(IXANY, "IXANY");
# endif
# ifdef IMAXBEL
    FOO(IMAXBEL, "IMAXBEL");
# endif
    fprintf(stderr, "\n");

# undef FOO
# define FOO(entry, name)					\
    fprintf(stderr, "%-8s = %#04o\n", name, tio->c_cc [entry])

    FOO(VINTR, "VINTR");
    FOO(VQUIT, "VQUIT");
    FOO(VERASE, "VERASE");
    FOO(VKILL, "VKILL");
    FOO(VEOF, "VEOF");
    FOO(VEOL, "VEOL");
# ifdef VEOL2
    FOO(VEOL2, "VEOL2");
# endif
# ifdef VSWTC
    FOO(VSWTC, "VSWTC");
# endif
# ifdef VSWTCH
    FOO(VSWTCH, "VSWTCH");
# endif
    FOO(VSTART, "VSTART");
    FOO(VSTOP, "VSTOP");
    FOO(VSUSP, "VSUSP");
# ifdef VDSUSP
    FOO(VDSUSP, "VDSUSP");
# endif
# ifdef VREPRINT
    FOO(VREPRINT, "VREPRINT");
# endif
# ifdef VDISCRD
    FOO(VDISCRD, "VDISCRD");
# endif
# ifdef VWERSE
    FOO(VWERSE, "VWERSE");
# endif
# ifdef VLNEXT
    FOO(VLNEXT, "VLNEXT");
# endif
    fprintf(stderr, "\n");
# undef FOO
# endif				/* HAVE_TERMIOS_H */
#endif				/* DEBUG_TTYMODE */
}

/*----------------------- end-of-file (C source) -----------------------*/
