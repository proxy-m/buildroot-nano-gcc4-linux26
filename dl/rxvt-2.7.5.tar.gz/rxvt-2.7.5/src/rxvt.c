#include "../config.h"
#include "rxvt.h"

rxvt_t          rxvt_vars;
/*----------------------------------------------------------------------*/
/* main() */
/* INTPROTO */
int
main(int argc, const char *const *argv)
{
    if (rxvt_init(&rxvt_vars, argc, argv) < 0)
	return EXIT_FAILURE;
    rxvt_main_loop(&rxvt_vars);	/* main processing loop */
    return EXIT_SUCCESS;
}
